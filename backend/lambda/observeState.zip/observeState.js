const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
    DynamoDBDocumentClient,
    UpdateCommand,
} = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    for (const record of event.Records) {

        console.log(record)
        // 1️⃣ Prüfen: was ist passiert?
        let delta = 0;
        if (record.eventName === "INSERT") delta = 1;
        if (record.eventName === "REMOVE") delta = -1;
        if (delta === 0) continue;

        // 2️⃣ Globalen Zustand atomar updaten
        await dynamodb.send(
            new UpdateCommand({
                TableName: "GlobalState",
                Key: { pk: "FETCH_STATE" },

                UpdateExpression: `
          ADD activeConnections :delta
          SET isActive = activeConnections + :delta > :zero
        `,

                ExpressionAttributeValues: {
                    ":delta": delta,
                    ":zero": 0,
                },
            })
        );
    }
};
